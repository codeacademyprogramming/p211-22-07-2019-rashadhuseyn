﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace P211_CSharp_SLQ
{
    public partial class Form1 : Form
    {
        private readonly string connectionString = ConfigurationManager.ConnectionStrings["default"].ConnectionString;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Steps - Addimlar
            //1. Connect to SQL
            //2. Load all countries
            //3. Fill comboboxCountries with data
            //4. Close connection with SQL

            #region try-catch-finally version
            //SqlConnection conn = null;
            //SqlCommand command = null;
            //SqlDataReader reader = null;
            //try
            //{
            //    string connectionString = "Server = localhost; Database = P211_Blog; Integrated Security = sspi;";

            //    conn = new SqlConnection(connectionString);

            //    conn.Open();

            //    string commandText = "select * from Countries order by Id";

            //    command = new SqlCommand(commandText, conn);

            //    reader = command.ExecuteReader();

            //    while (reader.Read())
            //    {
            //        cmbCountries.Items.Add(reader.GetInt32(0) + " " + reader.GetString(1));
            //    }
            //}
            //catch(Exception ex)
            //{
            //    Console.WriteLine(ex.Message);
            //}
            //finally
            //{
            //    reader.Close();
            //    command.Dispose();
            //    conn.Close();
            //}
            #endregion

            FillComboCountries();
        }

        private void FillComboCountries()
        {
            cmbCountries.Items.Clear();


            #region using directive way
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string commandText = "select * from Countries order by Id";

                using (SqlCommand command = new SqlCommand(commandText, conn))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            cmbCountries.Items.Add(reader.GetString(1));
                        }
                    }
                }
            }
            #endregion
        }

        private void CmbCountries_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbCities.Items.Clear();

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string commandText = "select Cities.Id, Cities.Name " +
                                     "from Cities " +
                                     "join Countries on Cities.CountryId = Countries.Id " +
                                     $"where Countries.Name = '{cmbCountries.Text}'";

                using (SqlCommand sqlCommand = new SqlCommand(commandText, conn))
                {
                    using(SqlDataReader reader = sqlCommand.ExecuteReader())
                    {
                        if(reader.HasRows)
                        {
                            while(reader.Read())
                            {
                                cmbCities.Items.Add(reader.GetString(1));
                            }
                        }
                        else
                        {
                            MessageBox.Show($"{cmbCountries.Text} has no cities in our database.");
                        }
                    }
                }

            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string country = txtCountry.Text.Trim();

            if(country != string.Empty)
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string commandText = $"select * from Countries where Name = '{country}'";

                    using(SqlCommand command = new SqlCommand(commandText, conn))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                MessageBox.Show("This country already exists!!!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }

                        command.CommandText = $"insert into Countries values('{country}')";
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected >= 1)
                        {
                            MessageBox.Show($"{country} was successfully added", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            txtCountry.Text = "";
                            FillComboCountries();
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Ramiz eseblesir!!!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
